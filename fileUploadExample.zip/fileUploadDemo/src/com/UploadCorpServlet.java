package com;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;

import javax.imageio.ImageIO;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;
public class UploadCorpServlet extends HttpServlet {
	   private boolean isMultipart;
	   private String downloadPath;
	   private int maxFileSize = 9000 * 1024;
	   private int maxMemSize = 900 * 1024;
	   private File file ;
	   int cropHeight;
	   int cropWidth;
	   int windowLeft;
	   int windowTop;
	   public void init( ){
	      // Get the file location where it would be stored.
	      downloadPath = 
	             getServletContext().getInitParameter("file-upload"); 
	   }
	   public void doPost(HttpServletRequest request, 
	               HttpServletResponse response)
	              throws ServletException, java.io.IOException {
//		   System.out.println(request.getParameter("das"));
//		   System.out.println(request.getParameter("cropWidth"));
//		   System.out.println(request.getParameter("windowLeft"));
//		   System.out.println(request.getParameter("windowTop"));
//		   cropHeight=100;//(int)Double.parseDouble(request.getParameter("cropHeight"));
//		   cropWidth=200;//(int)Double.parseDouble(request.getParameter("cropWidth"));
//		   windowLeft=100;//(int)Double.parseDouble(request.getParameter("windowLeft"));
//		   windowTop=100;//(int)Double.parseDouble(request.getParameter("windowTop"));
		   
	      // Check that we have a file upload request
	      isMultipart = ServletFileUpload.isMultipartContent(request);
	      response.setContentType("text/html");
	      java.io.PrintWriter out = response.getWriter( );
	      if( !isMultipart ){
	         out.println("<html>");
	         out.println("<p>No file uploaded</p>"); 
	         out.println("</html>");
	         return;
	      }
	      String fileName=FileUploadSvc.uploadWithCrop(maxMemSize, maxFileSize, request, downloadPath, 0, "jpg");

	            out.println("Uploaded Filename:" +fileName+"<br>");

	   }
	   public void doGet(HttpServletRequest request, 
	                       HttpServletResponse response)
	        throws ServletException, java.io.IOException {
	        
	        throw new ServletException("GET method used with " +
	                getClass( ).getName( )+": POST method required.");
	   } 
}
