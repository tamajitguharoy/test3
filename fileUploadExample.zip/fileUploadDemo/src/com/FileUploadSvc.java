package com;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Iterator;
import java.util.List;

import javax.imageio.IIOImage;
import javax.imageio.ImageIO;
import javax.imageio.ImageWriteParam;
import javax.imageio.ImageWriter;
import javax.imageio.stream.FileImageOutputStream;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

public class FileUploadSvc {
public static String  upload(int maxMemSize,int maxFileSize,HttpServletRequest request,String downloadPath){
    String fieldName = null;
    String fileName = null;
    String contentType = null;
	DiskFileItemFactory factory = new DiskFileItemFactory();
    
    // maximum size that will be stored in memory
    factory.setSizeThreshold(maxMemSize);
    // Location to save data that is larger than maxMemSize.
    factory.setRepository(new File("c:\\temp"));
    
    // Create a new file upload handler
    ServletFileUpload upload = new ServletFileUpload(factory);
    // maximum file size to be uploaded.
    upload.setSizeMax( maxFileSize );

    try{ 
    // Parse the request to get file items.
    List fileItems = upload.parseRequest(request);
	
    // Process the uploaded file items
    Iterator i = fileItems.iterator();


    while ( i.hasNext () ) 
    {
       FileItem fi = (FileItem)i.next();
       if ( !fi.isFormField () )	
       {
          // Get the uploaded file parameters
           fieldName = fi.getFieldName();
           fileName = fi.getName();
           contentType = fi.getContentType();
          boolean isInMemory = fi.isInMemory();
          long sizeInBytes = fi.getSize();
          // Write the file
          File file=null;
    
             file = new File( downloadPath + fileName) ;

          fi.write( file ) ;
         
       }
    }
    }catch(Exception ex) {
	       System.out.println(ex);
	   }
return fileName;
}

public static String  uploadWithCrop(int maxMemSize,int maxFileSize,HttpServletRequest request,String downloadPath,int commonPadding,String fileFormat){
	File file=null;
	String fieldName = null;
    String fileName = null;
    String contentType = null;
	int cropHeight=0;
	int cropWidth=0;
	int windowLeft=0;
	int windowTop=0;
	int imageHeight=0;
	int imageWidth=0;
	DiskFileItemFactory factory = new DiskFileItemFactory();
    
    // maximum size that will be stored in memory
    factory.setSizeThreshold(maxMemSize);
    // Location to save data that is larger than maxMemSize.
    factory.setRepository(new File("c:\\temp"));
    
    // Create a new file upload handler
    ServletFileUpload upload = new ServletFileUpload(factory);
    // maximum file size to be uploaded.
    upload.setSizeMax( maxFileSize );

    try{ 
    // Parse the request to get file items.
    List fileItems = upload.parseRequest(request);
	
    
    
    // Process the uploaded file items
    Iterator i = fileItems.iterator();


    while ( i.hasNext () ) 
    {
       FileItem fi = (FileItem)i.next();
       if ( !fi.isFormField () )	
       {
          // Get the uploaded file parameters
           fieldName = fi.getFieldName();
           fileName = fi.getName();
           contentType = fi.getContentType();
          boolean isInMemory = fi.isInMemory();
          long sizeInBytes = fi.getSize();
          // Write the file
//             file = new File( downloadPath + "original_"+fileName);
//             fi.write( file );
             
//             byte[] imgByte=fi.get();
             
//             InputStream in = new ByteArrayInputStream(imgByte);
 			BufferedImage bImageFromConvert = ImageIO.read(fi.getInputStream());
  
 			
 			
 			
 			
 			ImageIO.write(bImageFromConvert, "jpg", new File(
 					downloadPath + "original_"+fileName));
             
             
             
             
          }else{
    	   if(fi.getFieldName().equals("cropHeight")){
    		   cropHeight=(int)Double.parseDouble(fi.getString());  
    	   }else if(fi.getFieldName().equals("cropWidth")){
    		   cropWidth=(int)Double.parseDouble(fi.getString());
    	   }else if(fi.getFieldName().equals("windowLeft")){
    		   windowLeft=(int)Double.parseDouble(fi.getString());
    	   }else if(fi.getFieldName().equals("windowTop")){
    		   windowTop=(int)Double.parseDouble(fi.getString());
    	   }else if(fi.getFieldName().equals("imageHeight")){
    		   imageHeight=(int)Double.parseDouble(fi.getString());
    	   }else if(fi.getFieldName().equals("imageWidth")){
    		   imageWidth=(int)Double.parseDouble(fi.getString());
    	   }
       }
    }
    String destpath=  scaleImage(imageHeight,imageWidth,file,downloadPath,fileName,fileFormat);
    String cropDestpath= cropImage(cropHeight,cropWidth,windowLeft,windowTop,new File(destpath),downloadPath,fileName,commonPadding,fileFormat);
    reduceImageQuality((int)(new File(cropDestpath).length()*.8),cropDestpath,downloadPath,"com_"+fileName);
    }catch(Exception ex) {
	       System.out.println(ex);
	   }
return fileName;
}


public static String cropImage(int cropHeight,int cropWidth,int windowLeft,int windowTop,File srcFile,String destDirectory,String destFilename,int commonPadding,String fileFormat)throws IOException{
    boolean isOkResolution=false;
    String destpath=null;
    try {
      
        File f=new File(destDirectory);
        if(!f.isDirectory()){
            f.mkdir();
        }
        destpath=destDirectory+"/"+destFilename;
        File outputFile=new File(destpath);
        FileInputStream fis=new FileInputStream(srcFile);
        
        
        BufferedImage bimage=ImageIO.read(fis);
        System.out.println("Image Origilnal Height=="+bimage.getHeight());
        BufferedImage oneimg=new BufferedImage(cropWidth,cropHeight,bimage.getType());
        Graphics2D gr2d=oneimg.createGraphics();
      //  isOkResolution=gr2d.drawImage(bimage,0,0,cropWidth,cropHeight,windowLeft-commonPadding,windowTop-commonPadding,(windowLeft+cropWidth)-commonPadding,(windowTop+cropHeight)-commonPadding,null);
        isOkResolution=gr2d.drawImage(bimage,0,0,cropWidth,cropHeight,windowLeft,windowTop,windowLeft+cropWidth,windowTop+cropHeight,null);
        
        
        //isOkResolution=gr2d.drawImage(
        gr2d.dispose();
        ImageIO.write(oneimg,fileFormat,outputFile);
        
    } catch (FileNotFoundException fe) {
        System.out.println("No File Found =="+fe);
    } catch(Exception ex){
        System.out.println("Error in Croping File="+ex);
        ex.printStackTrace();
    }
  
    return destpath;
}

public static String scaleImage(int cropHeight,int cropWidth,File srcFile,String destDirectory,String destFilename,String fileFormat)throws IOException{
    boolean isOkResolution=false;
    String destpath=null;
    try {
      
        File f=new File(destDirectory);
        if(!f.isDirectory()){
            f.mkdir();
        }
         destpath=destDirectory+"/scale_"+destFilename;
        File outputFile=new File(destpath);
        FileInputStream fis=new FileInputStream(srcFile);
        
        
        BufferedImage bimage=ImageIO.read(fis);
        System.out.println("Image Origilnal Height=="+bimage.getHeight());
        BufferedImage oneimg=new BufferedImage(cropWidth,cropHeight,bimage.getType());
        Graphics2D gr2d=oneimg.createGraphics();
      //  isOkResolution=gr2d.drawImage(bimage,0,0,cropWidth,cropHeight,windowLeft-commonPadding,windowTop-commonPadding,(windowLeft+cropWidth)-commonPadding,(windowTop+cropHeight)-commonPadding,null);
        isOkResolution=gr2d.drawImage(bimage,0,0,cropWidth,cropHeight,null);
        //,windowLeft,windowTop,windowLeft+cropWidth,windowTop+cropHeight
        
        //isOkResolution=gr2d.drawImage(
        gr2d.dispose();
        ImageIO.write(oneimg,fileFormat,outputFile);
        
    } catch (FileNotFoundException fe) {
        System.out.println("No File Found =="+fe);
    } catch(Exception ex){
        System.out.println("Error in Croping File="+ex);
        ex.printStackTrace();
    }
  
    return destpath;
}
public static void main(String[] args ) throws Exception{
	   try {
		   
		   //cropImage(89, 158, 588, 470,new File("C:\\Documents and Settings\\All Users\\Documents\\My Pictures\\Sample Pictures\\Winter.jpg"),"d:/camel","demo3.jpg", 50,"jpg");
		  
		   System.out.println(new File("d:/camel/Water lilies.jpg").length());
		   reduceImageQuality((int)(new File("d:/camel/Water lilies.jpg").length()*.8), "d:/camel/Water lilies.jpg", "d:/camel/","Water lilies_com.jpg");
		   
	} catch (IOException e) {
		e.printStackTrace();
	}
}

public static void reduceImageQuality(int sizeThreshold, String srcImg, String destDir, String destFile) throws Exception {
    float quality = 1.0f;

    File file = new File(srcImg);

    long fileSize = file.length();

/*    if (fileSize <= 10000) {
        System.out.println("Image file size is under threshold");
        return;
    }*/

    Iterator iter = ImageIO.getImageWritersByFormatName("jpeg");

    ImageWriter writer = (ImageWriter) iter.next();

    ImageWriteParam iwp = writer.getDefaultWriteParam();

    iwp.setCompressionMode(ImageWriteParam.MODE_EXPLICIT);

    FileInputStream inputStream = new FileInputStream(file);

    BufferedImage originalImage = ImageIO.read(inputStream);
    IIOImage image = new IIOImage(originalImage, null, null);
    inputStream.close();

    float percent = 0.1f;   // 10% of 1

    while (fileSize > sizeThreshold) {
        if (percent >= quality) {
            percent = percent * 0.1f;
        }

        quality -= percent;

        File fileOut = new File(destDir+destFile);
        if (fileOut.exists()) {
            fileOut.delete();
        }
        FileImageOutputStream output = new FileImageOutputStream(fileOut);

        writer.setOutput(output);

        iwp.setCompressionQuality(quality);

        writer.write(null, image, iwp);

        File fileOut2 = new File(destDir+destFile);
        long newFileSize = fileOut2.length();
        if (newFileSize == fileSize) {
            // cannot reduce more, return
            break;
        } else {
            fileSize = newFileSize;
        }
        System.out.println("quality = " + quality + ", new file size = " + fileSize);
        output.close();
    }

    writer.dispose();
}

}

