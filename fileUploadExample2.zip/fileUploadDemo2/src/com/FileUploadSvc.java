package com;

import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.Iterator;
import java.util.List;

import javax.imageio.IIOImage;
import javax.imageio.ImageIO;
import javax.imageio.ImageWriteParam;
import javax.imageio.ImageWriter;
import javax.imageio.stream.FileImageOutputStream;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

public class FileUploadSvc {
	public static String upload(int maxMemSize, int maxFileSize,
			HttpServletRequest request, String downloadPath) {
		String fieldName = null;
		String fileName = null;
		String contentType = null;
		DiskFileItemFactory factory = new DiskFileItemFactory();

		// maximum size that will be stored in memory
		factory.setSizeThreshold(maxMemSize);
		// Location to save data that is larger than maxMemSize.
		factory.setRepository(new File("c:\\temp"));

		// Create a new file upload handler
		ServletFileUpload upload = new ServletFileUpload(factory);
		// maximum file size to be uploaded.
		upload.setSizeMax(maxFileSize);

		try {
			// Parse the request to get file items.
			List fileItems = upload.parseRequest(request);

			// Process the uploaded file items
			Iterator i = fileItems.iterator();

			while (i.hasNext()) {
				FileItem fi = (FileItem) i.next();
				if (!fi.isFormField()) {
					// Get the uploaded file parameters
					fieldName = fi.getFieldName();
					fileName = fi.getName();
					contentType = fi.getContentType();
					boolean isInMemory = fi.isInMemory();
					long sizeInBytes = fi.getSize();
					// Write the file
					File file = null;

					file = new File(downloadPath + fileName);

					fi.write(file);

				}
			}
		} catch (Exception ex) {
			System.out.println(ex);
		}
		return fileName;
	}

	public static String uploadWithCrop(int maxMemSize, int maxFileSize,
			HttpServletRequest request, String downloadPath, int commonPadding,
			String fileFormat) {
		File file = null;
		String fieldName = null;
		String fileName = null;
		String contentType = null;
		int cropHeight = 0;
		int cropWidth = 0;
		int windowLeft = 0;
		int windowTop = 0;
		int imageHeight = 0;
		int imageWidth = 0;
		DiskFileItemFactory factory = new DiskFileItemFactory();

		// maximum size that will be stored in memory
		factory.setSizeThreshold(maxMemSize);
		// Location to save data that is larger than maxMemSize.
		factory.setRepository(new File("c:\\temp"));

		// Create a new file upload handler
		ServletFileUpload upload = new ServletFileUpload(factory);
		// maximum file size to be uploaded.
		upload.setSizeMax(maxFileSize);

		try {
			// Parse the request to get file items.
			List fileItems = upload.parseRequest(request);

			// Process the uploaded file items
			Iterator i = fileItems.iterator();
			BufferedImage bufferedImage = null;

			while (i.hasNext()) {
				FileItem fi = (FileItem) i.next();
				if (!fi.isFormField()) {
					// Get the uploaded file parameters
					fieldName = fi.getFieldName();
					fileName = fi.getName();
					contentType = fi.getContentType();
					boolean isInMemory = fi.isInMemory();
					long sizeInBytes = fi.getSize();

					bufferedImage = ImageIO.read(fi.getInputStream());

					// ImageIO.write(bufferedImage, "jpg", new File(downloadPath
					// + "original_" + fileName));

				} else {
					if (fi.getFieldName().equals("cropHeight")) {
						cropHeight = (int) Double.parseDouble(fi.getString());
					} else if (fi.getFieldName().equals("cropWidth")) {
						cropWidth = (int) Double.parseDouble(fi.getString());
					} else if (fi.getFieldName().equals("windowLeft")) {
						windowLeft = (int) Double.parseDouble(fi.getString());
					} else if (fi.getFieldName().equals("windowTop")) {
						windowTop = (int) Double.parseDouble(fi.getString());
					} else if (fi.getFieldName().equals("imageHeight")) {
						imageHeight = (int) Double.parseDouble(fi.getString());
					} else if (fi.getFieldName().equals("imageWidth")) {
						imageWidth = (int) Double.parseDouble(fi.getString());
					}
				}
			}
			BufferedImage bufferedImage2 = scaleImage(imageHeight, imageWidth,
					bufferedImage, downloadPath, fileName, fileFormat);
			BufferedImage bufferedImage3 = cropImage(cropHeight, cropWidth,
					windowLeft, windowTop, bufferedImage2, downloadPath,
					fileName, commonPadding, fileFormat);

		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return fileName;
	}

	public static BufferedImage cropImage(int cropHeight, int cropWidth,
			int windowLeft, int windowTop, BufferedImage bufferedImage,
			String destDirectory, String destFilename, int commonPadding,
			String fileFormat) throws IOException {
		BufferedImage oneimg = null;
		try {
			String destpath = destDirectory + "/" + destFilename;
			oneimg = new BufferedImage(cropWidth, cropHeight,
					bufferedImage.getType());
			Graphics2D gr2d = oneimg.createGraphics();
			gr2d.drawImage(bufferedImage, 0, 0, cropWidth, cropHeight,
					windowLeft, windowTop, windowLeft + cropWidth, windowTop
							+ cropHeight, null);
			gr2d.dispose();

			ByteArrayOutputStream baos = new ByteArrayOutputStream();
			ImageIO.write(oneimg, fileFormat, baos);
			baos.flush();
			int imgSize = baos.size();
			if (imgSize > 111) {
				reduceImageQuality((int)(imgSize * .8), oneimg, destDirectory,
						"/" + destFilename);
			} else {
				ImageIO.write(oneimg, fileFormat, new File(destpath));
			}

		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return oneimg;
	}

	public static BufferedImage scaleImage(int cropHeight, int cropWidth,
			BufferedImage bufferedImage, String destDirectory,
			String destFilename, String fileFormat) throws IOException {
		BufferedImage oneimg = null;
		try {
			// String destpath = destDirectory + "/scale_" + destFilename;
			oneimg = new BufferedImage(cropWidth, cropHeight,
					bufferedImage.getType());
			Graphics2D gr2d = oneimg.createGraphics();
			gr2d.drawImage(bufferedImage, 0, 0, cropWidth, cropHeight, null);
			gr2d.dispose();
			// ImageIO.write(oneimg, fileFormat, new File(destpath));

		} catch (Exception ex) {
			ex.printStackTrace();
		}
		return oneimg;
	}

	public static void main(String[] args) throws Exception {
			// cropImage(89, 158, 588, 470,new
			// File("C:\\Documents and Settings\\All Users\\Documents\\My Pictures\\Sample Pictures\\Winter.jpg"),"d:/camel","demo3.jpg",
			// 50,"jpg");

			System.out.println(new File("d:/camel/Water lilies.jpg").length());
//			reduceImageQuality(
//					(int) (new File("d:/camel/Water lilies.jpg").length() * .8),
//					"d:/camel/Water lilies.jpg", "d:/camel/",
//					"Water lilies_com.jpg");


	}

	public static void reduceImageQuality(int sizeThreshold, BufferedImage bufferedImage,
			String destDir, String destFile) throws Exception {
		float quality = 1.0f;

//		File file = new File(srcImg);

	long fileSize =(long)(sizeThreshold/.8);

		/*
		 * if (fileSize <= 10000) {
		 * System.out.println("Image file size is under threshold"); return; }
		 */

		Iterator iter = ImageIO.getImageWritersByFormatName("jpeg");

		ImageWriter writer = (ImageWriter) iter.next();

		ImageWriteParam iwp = writer.getDefaultWriteParam();

		iwp.setCompressionMode(ImageWriteParam.MODE_EXPLICIT);

//		FileInputStream inputStream = new FileInputStream(file);
//
//		BufferedImage originalImage = ImageIO.read(inputStream);
		IIOImage image = new IIOImage(bufferedImage, null, null);
	//	inputStream.close();

		float percent = 0.1f; // 10% of 1

		while (fileSize > sizeThreshold) {
			if (percent >= quality) {
				percent = percent * 0.1f;
			}

			quality -= percent;

			File fileOut = new File(destDir + destFile);
			if (fileOut.exists()) {
				fileOut.delete();
			}
			FileImageOutputStream output = new FileImageOutputStream(fileOut);

			writer.setOutput(output);

			iwp.setCompressionQuality(quality);

			writer.write(null, image, iwp);

			File fileOut2 = new File(destDir + destFile);
			long newFileSize = fileOut2.length();
			if (newFileSize == fileSize) {
				// cannot reduce more, return
				break;
			} else {
				fileSize = newFileSize;
			}
			System.out.println("quality = " + quality + ", new file size = "
					+ fileSize);
			output.close();
		}

		writer.dispose();
	}

}
